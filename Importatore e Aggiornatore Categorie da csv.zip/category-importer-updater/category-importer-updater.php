<?php
/**
 * Plugin Name: Importatore e Aggiornatore Categorie con Tag Groups
 * Plugin URI: https://github.com/salvatoresalvo/category-importer-updater
 * Description:  Category Importer and Updater with Tag Groups | Un plugin che consente di importare e aggiornare le categorie di WordPress con supporto per campi personalizzati come Tag Gruppo.
 * Version: 1.2.0
 * Author: Salvatore Iovino (salvatoresalvo)
 * Author URI: https://www.salvatoreiovino.it
 * License: GPL v3
 * GitHub Plugin URI: https://github.com/salvatoresalvo/category-importer-updater
 */


// Evitare l'accesso diretto
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Classe principale del plugin
 */
class Category_Importer_Updater {

    /**
     * Costruttore
     */
    public function __construct() {
        // Aggiungi le voci di menu
        add_action('admin_menu', array($this, 'add_admin_menu'));

        // Registra le risorse CSS/JS
        add_action('admin_enqueue_scripts', array($this, 'register_admin_scripts'));

        // Aggiungi l'azione AJAX per l'elaborazione dei file CSV
        add_action('wp_ajax_process_category_csv', array($this, 'process_category_csv'));
    }

    /**
     * Aggiunge le voci di menu al pannello di amministrazione
     */
    public function add_admin_menu() {
        add_menu_page(
            'Importatore Categorie', 
            'Importatore Categorie', 
            'manage_categories', 
            'category-importer-updater', 
            array($this, 'render_admin_page'), 
            'dashicons-category', 
            30
        );
    }

    /**
     * Registra gli script e gli stili CSS
     */
    public function register_admin_scripts($hook) {
        if ($hook != 'toplevel_page_category-importer-updater') {
            return;
        }

        wp_enqueue_style(
            'category-importer-updater-css', 
            plugin_dir_url(__FILE__) . 'assets/css/admin.css', 
            array(), 
            '1.0.0'
        );

        wp_enqueue_script(
            'category-importer-updater-js', 
            plugin_dir_url(__FILE__) . 'assets/js/admin.js', 
            array('jquery'), 
            '1.0.0', 
            true
        );

        wp_localize_script(
            'category-importer-updater-js', 
            'categoryImporterData', 
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('category-importer-nonce')
            )
        );
    }

    /**
     * Renderizza la pagina di amministrazione
     */
    public function render_admin_page() {
        ?>
        <div class="wrap">
            <h1>Importatore e Aggiornatore Categorie</h1>
            
            <div class="card">
                <h2>Importa Categorie da CSV</h2>
                <p>Usa questo strumento per importare nuove categorie o aggiornare quelle esistenti senza eliminarle.</p>
                
                <form id="category-import-form" enctype="multipart/form-data">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="category_csv">File CSV</label></th>
                            <td>
                                <input type="file" name="category_csv" id="category_csv" accept=".csv" required>
                                <p class="description">Il file CSV deve contenere almeno le colonne: "Nome", "Descrizione" (opzionale), "Slug" (opzionale), "Tag Gruppo" (opzionale), "Categoria genitore" (opzionale).</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Opzioni</th>
                            <td>
                                <fieldset>
                                    <label for="update_existing">
                                        <input type="checkbox" name="update_existing" id="update_existing" value="1" checked>
                                        Aggiorna le categorie esistenti (se trovate in base al nome o allo slug)
                                    </label>
                                </fieldset>
                                <fieldset>
                                    <label for="create_missing_parents">
                                        <input type="checkbox" name="create_missing_parents" id="create_missing_parents" value="1" checked>
                                        Crea categorie parent mancanti
                                    </label>
                                </fieldset>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <input type="submit" name="submit" id="submit" class="button button-primary" value="Importa Categorie">
                    </p>
                </form>
                
                <div id="import-results" style="display: none;">
                    <h3>Risultati dell'importazione</h3>
                    <div class="results-container"></div>
                </div>
            </div>
            
            <div class="card" style="margin-top: 20px;">
                <h2>Istruzioni</h2>
                <p>Il file CSV deve avere i seguenti campi:</p>
                <ul>
                    <li><strong>Nome</strong> (obbligatorio): Il nome della categoria</li>
                    <li><strong>Descrizione</strong> (opzionale): La descrizione della categoria</li>
                    <li><strong>Slug</strong> (opzionale): Lo slug URL della categoria. Se non specificato, verrà generato dal nome.</li>
                    <li><strong>Tag Gruppo</strong> (opzionale): Il gruppo di tag associato alla categoria</li>
                    <li><strong>Categoria genitore</strong> (opzionale): Il nome della categoria genitore. Se non esiste, può essere creata automaticamente.</li>
                </ul>
                
                <p>Esempio di CSV:</p>
                <pre>Nome,Descrizione,Slug,Tag Gruppo,Categoria genitore
Alloggio,"Descrizione dell'alloggio",alloggio,alloggio,
Assicurazione,"L'assicurazione di viaggio offre protezione durante gli spostamenti",assicurazione,assicurazione,
Assicurazione di viaggio,"",assicurazione-di-viaggio,assicurazione-viaggio,Assicurazione</pre>
            </div>
        </div>
        <?php
    }

    /**
     * Recupera un valore dal CSV supportando più possibili nomi di colonna
     */
    private function get_csv_value($column_map, $row, $possible_column_names) {
        foreach ($possible_column_names as $column_name) {
            if (isset($column_map[$column_name]) && isset($row[$column_map[$column_name]]) && $row[$column_map[$column_name]] !== '') {
                if ($column_name == 'Descrizione' || $column_name == 'descrizione') {
                    return sanitize_textarea_field($row[$column_map[$column_name]]);
                } elseif ($column_name == 'Slug' || $column_name == 'slug') {
                    return sanitize_title($row[$column_map[$column_name]]);
                } else {
                    return sanitize_text_field($row[$column_map[$column_name]]);
                }
            }
        }
        return '';
    }
    
    /**
     * Elabora il file CSV tramite AJAX
     */
    public function process_category_csv() {
        // Verifica il nonce
        check_ajax_referer('category-importer-nonce', 'nonce');
        
        // Verifica le autorizzazioni
        if (!current_user_can('manage_categories')) {
            wp_send_json_error(array('message' => 'Permessi insufficienti.'));
            exit;
        }
        
        // Verifica che il file sia stato caricato
        if (empty($_FILES['category_csv']) || $_FILES['category_csv']['error'] > 0) {
            wp_send_json_error(array('message' => 'Errore nel caricamento del file.'));
            exit;
        }
        
        // Ottieni il percorso temporaneo del file
        $tmp_file = $_FILES['category_csv']['tmp_name'];
        
        // Ottieni le opzioni
        $update_existing = isset($_POST['update_existing']) ? true : false;
        $create_missing_parents = isset($_POST['create_missing_parents']) ? true : false;
        
        // Apri il file CSV
        $file = fopen($tmp_file, 'r');
        if (!$file) {
            wp_send_json_error(array('message' => 'Impossibile aprire il file CSV.'));
            exit;
        }
        
        // Leggi l'intestazione
        $header = fgetcsv($file);
        if (!$header) {
            wp_send_json_error(array('message' => 'File CSV non valido.'));
            fclose($file);
            exit;
        }
        
        // Mappa le colonne
        $column_map = array();
        foreach ($header as $index => $column_name) {
            $column_name = trim($column_name);
            $column_map[$column_name] = $index;
            
            // Supporta anche le versioni in minuscolo delle colonne
            $column_map[strtolower($column_name)] = $index;
        }
        
        // Verifica che le colonne obbligatorie siano presenti
        if (!isset($column_map['Nome']) && !isset($column_map['nome'])) {
            wp_send_json_error(array('message' => 'La colonna "Nome" è obbligatoria nel file CSV.'));
            fclose($file);
            exit;
        }
        
        // Inizializza i contatori
        $stats = array(
            'created' => 0,
            'updated' => 0,
            'skipped' => 0,
            'errors' => 0,
            'details' => array()
        );
        
        // Elabora ogni riga
        while (($row = fgetcsv($file)) !== false) {
            // Ottieni i dati della categoria
            $category_data = array(
                'name' => $this->get_csv_value($column_map, $row, ['Nome', 'nome']),
                'slug' => $this->get_csv_value($column_map, $row, ['Slug', 'slug']),
                'description' => $this->get_csv_value($column_map, $row, ['Descrizione', 'descrizione']),
                'parent' => $this->get_csv_value($column_map, $row, ['Categoria genitore', 'genitore']),
                'tag_group' => $this->get_csv_value($column_map, $row, ['Tag Gruppo', 'tag gruppo'])
            );
            
            // Verifica che il nome non sia vuoto
            if (empty($category_data['name'])) {
                $stats['skipped']++;
                $stats['details'][] = array(
                    'name' => '(vuoto)',
                    'status' => 'skipped',
                    'message' => 'Nome categoria mancante.'
                );
                continue;
            }
            
            // Cerca la categoria esistente
            $existing_term = null;
            
            // Cerca per slug, se disponibile
            if (!empty($category_data['slug'])) {
                $existing_term = get_term_by('slug', $category_data['slug'], 'category');
            }
            
            // Cerca per nome, se non trovata per slug
            if (!$existing_term) {
                $existing_term = get_term_by('name', $category_data['name'], 'category');
            }
            
            // Determina il genitore ID
            $parent_id = 0;
            if (!empty($category_data['parent'])) {
                $parent_term = get_term_by('name', $category_data['parent'], 'category');
                
                if (!$parent_term && $create_missing_parents) {
                    // Crea il genitore mancante
                    $parent_result = wp_insert_term(
                        $category_data['parent'],
                        'category',
                        array(
                            'slug' => sanitize_title($category_data['parent']),
                            'description' => '',
                        )
                    );
                    
                    if (!is_wp_error($parent_result)) {
                        $parent_id = $parent_result['term_id'];
                    }
                } elseif ($parent_term) {
                    $parent_id = $parent_term->term_id;
                }
            }
            
            // Prepara i dati per l'inserimento/aggiornamento
            $term_args = array(
                'description' => $category_data['description'],
                'parent' => $parent_id
            );
            
            if (!empty($category_data['slug'])) {
                $term_args['slug'] = $category_data['slug'];
            }
            
            // Ulteriori meta dati per la categoria
            $custom_meta = array();
            if (!empty($category_data['tag_group'])) {
                $custom_meta['tag_group'] = $category_data['tag_group'];
            }
            
            // Esegui l'operazione appropriata
            if ($existing_term) {
                if ($update_existing) {
                    // Aggiorna la categoria esistente
                    $result = wp_update_term($existing_term->term_id, 'category', $term_args);
                    
                    if (!is_wp_error($result)) {
                        // Aggiorna i meta dati personalizzati
                        $term_id = $result['term_id'];
                        foreach ($custom_meta as $meta_key => $meta_value) {
                            update_term_meta($term_id, $meta_key, $meta_value);
                        }
                        
                        $stats['updated']++;
                        $stats['details'][] = array(
                            'name' => $category_data['name'],
                            'status' => 'updated',
                            'message' => 'Categoria aggiornata con successo.'
                        );
                    } else {
                        $stats['errors']++;
                        $stats['details'][] = array(
                            'name' => $category_data['name'],
                            'status' => 'error',
                            'message' => 'Errore nell\'aggiornamento: ' . $result->get_error_message()
                        );
                    }
                } else {
                    // Salta la categoria esistente
                    $stats['skipped']++;
                    $stats['details'][] = array(
                        'name' => $category_data['name'],
                        'status' => 'skipped',
                        'message' => 'Categoria esistente, aggiornamento saltato.'
                    );
                }
            } else {
                // Crea una nuova categoria
                $result = wp_insert_term(
                    $category_data['name'],
                    'category',
                    $term_args
                );
                
                if (!is_wp_error($result)) {
                    // Aggiungi i meta dati personalizzati alla nuova categoria
                    $term_id = $result['term_id'];
                    foreach ($custom_meta as $meta_key => $meta_value) {
                        add_term_meta($term_id, $meta_key, $meta_value, true);
                    }
                    
                    $stats['created']++;
                    $stats['details'][] = array(
                        'name' => $category_data['name'],
                        'status' => 'created',
                        'message' => 'Nuova categoria creata con successo.'
                    );
                } else {
                    $stats['errors']++;
                    $stats['details'][] = array(
                        'name' => $category_data['name'],
                        'status' => 'error',
                        'message' => 'Errore nella creazione: ' . $result->get_error_message()
                    );
                }
            }
        }
        
        // Chiudi il file
        fclose($file);
        
        // Invia i risultati
        wp_send_json_success(array(
            'stats' => $stats,
            'message' => sprintf(
                'Importazione completata. %d categorie create, %d aggiornate, %d saltate, %d errori.',
                $stats['created'],
                $stats['updated'],
                $stats['skipped'],
                $stats['errors']
            )
        ));
    }
}

// Inizializza il plugin
$category_importer_updater = new Category_Importer_Updater();

/**
 * Crea la struttura delle directory e i file necessari all'attivazione
 */
function category_importer_updater_activate() {
    // Crea le directory per CSS e JS se non esistono
    $plugin_dir = plugin_dir_path(__FILE__);
    
    if (!file_exists($plugin_dir . 'assets')) {
        mkdir($plugin_dir . 'assets');
    }
    
    if (!file_exists($plugin_dir . 'assets/css')) {
        mkdir($plugin_dir . 'assets/css');
    }
    
    if (!file_exists($plugin_dir . 'assets/js')) {
        mkdir($plugin_dir . 'assets/js');
    }
    
    // Crea il file CSS
    $css_content = "/* Stili per l'importatore di categorie */
.card {
    background: #fff;
    border: 1px solid #ccd0d4;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    padding: 20px;
    margin-bottom: 20px;
}

.results-container {
    max-height: 400px;
    overflow-y: auto;
    border: 1px solid #ddd;
    padding: 10px;
    margin-top: 10px;
}

.import-result-item {
    padding: 8px;
    margin-bottom: 5px;
    border-left: 3px solid;
}

.import-result-item.created {
    border-left-color: #46b450;
    background-color: #ecf7ed;
}

.import-result-item.updated {
    border-left-color: #00a0d2;
    background-color: #e5f5fa;
}

.import-result-item.skipped {
    border-left-color: #ffb900;
    background-color: #fff8e5;
}

.import-result-item.error {
    border-left-color: #dc3232;
    background-color: #fbeaea;
}";
    
    file_put_contents($plugin_dir . 'assets/css/admin.css', $css_content);
    
    // Crea il file JS
    $js_content = "jQuery(document).ready(function($) {
    $('#category-import-form').on('submit', function(e) {
        e.preventDefault();
        
        var formData = new FormData(this);
        formData.append('action', 'process_category_csv');
        formData.append('nonce', categoryImporterData.nonce);
        
        // Aggiungi i valori delle checkbox
        formData.append('update_existing', $('#update_existing').is(':checked') ? '1' : '0');
        formData.append('create_missing_parents', $('#create_missing_parents').is(':checked') ? '1' : '0');
        
        $('#submit').prop('disabled', true).val('Importazione in corso...');
        
        $.ajax({
            url: categoryImporterData.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                $('#submit').prop('disabled', false).val('Importa Categorie');
                
                if (response.success) {
                    var stats = response.data.stats;
                    var resultsHtml = '<div class=\"notice notice-success inline\"><p>' + response.data.message + '</p></div>';
                    
                    // Aggiungi i dettagli
                    if (stats.details && stats.details.length > 0) {
                        resultsHtml += '<div class=\"results-container\">';
                        
                        $.each(stats.details, function(index, detail) {
                            resultsHtml += '<div class=\"import-result-item ' + detail.status + '\">';
                            resultsHtml += '<strong>' + detail.name + ':</strong> ' + detail.message;
                            resultsHtml += '</div>';
                        });
                        
                        resultsHtml += '</div>';
                    }
                    
                    $('#import-results').show().find('.results-container').html(resultsHtml);
                } else {
                    var errorMsg = response.data.message || 'Si è verificato un errore durante l\'importazione.';
                    $('#import-results').show().find('.results-container').html(
                        '<div class=\"notice notice-error inline\"><p>' + errorMsg + '</p></div>'
                    );
                }
            },
            error: function() {
                $('#submit').prop('disabled', false).val('Importa Categorie');
                $('#import-results').show().find('.results-container').html(
                    '<div class=\"notice notice-error inline\"><p>Errore di connessione al server.</p></div>'
                );
            }
        });
    });
});";
    
    file_put_contents($plugin_dir . 'assets/js/admin.js', $js_content);
}

// Registra la funzione di attivazione
register_activation_hook(__FILE__, 'category_importer_updater_activate');
